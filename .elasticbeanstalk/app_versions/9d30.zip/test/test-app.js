'use strict';
var angular;

angular.module('app', ['ngResource', 'ngRoute']);

var toastr = {};